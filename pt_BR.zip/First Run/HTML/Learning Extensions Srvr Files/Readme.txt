Os arquivos nesta pasta (e na subpasta) s�o usados para 
integra��o do conte�do Flash com LMS (Sistemas de 
gerenciamento de aprendizado) compat�veis com AICC.  
Esses arquivos precisam ser compilados para o Servidor Web 
na mesma pasta que o conte�do Flash de modo a fazer o 
rastreamento adequado para um LMS compat�vel com AICC.  

Para obter mais informa��es e instru��es sobre como usar 
esses arquivos, visite http://www.macromedia.com/support/flash